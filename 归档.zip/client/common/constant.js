export const BASE_HOST = 'https://www.hnmall.com/';

export const INSTALL_APP  = 'install_hnmall_app';